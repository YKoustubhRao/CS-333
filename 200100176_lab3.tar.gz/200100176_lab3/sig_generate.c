#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>

int main(int argc, char *argv[]){
    char *a = argv[1];
    int pid = atoi(a);
    kill(pid, SIGINT);
    printf("SIGINT signal sent to PID: %d\n", pid);
    kill(pid, SIGTERM);
    printf("SIGTERM signal sent to PID: %d\n", pid);
    kill(pid, SIGKILL);
    printf("SIGKILL signal sent to PID: %d\n", pid);
    return 0;
}
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

void f(int n){
    if(fork() == 0){
      printf("Child %d is created\n", getpid());
      sleep(1);
      printf("Child %d of parent %d exited\n", getpid(), getppid());
      exit(0);
    }
    else{
      return;
    }
}
int main(int argc, char *argv[]){
    char *a = argv[1];
    int n = atoi(a);
    for(int i = 0; i < n; i++){
      f(i);
    }
    wait(NULL);
    return 0;
}

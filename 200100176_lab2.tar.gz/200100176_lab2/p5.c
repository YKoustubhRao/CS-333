#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>


int main(){
    int p[2];
    pipe(p);
    if(fork() == 0){
      int x;
      scanf("%d",&x);
      write(p[1], &x, 4);
    }
    else{
      wait(NULL);
      if(fork() == 0){
        int y;
        int z;
        read(p[0], &z, 4);
        scanf("%d",&y);
        y = y + z;
        write(p[1], &y, 4);
      }
      else{
        wait(NULL);
        int sum;
        read(p[0], &sum, 4);
        printf("%d\n", sum);
      }
    }
    return 0;
}

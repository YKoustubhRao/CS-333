#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

void f(int n){
    if(n == 1){
      printf("Child %d is created\n", getpid());
      printf("Child %d with parent %d exited\n", getpid(), getppid());
      return;
    }
    else{
      wait(NULL);
      printf("Child %d is created\n", getpid());
      if(fork() == 0){
        f(n-1);
      }
      else{
        wait(NULL);
        printf("Child %d of parent %d exited\n", getpid(), getppid());
      }
    }
}
int main(int argc, char *argv[]){
    char *a = argv[1];
    int n = atoi(a);
    if(fork() == 0){
      f(n);
    }
    else{
      wait(NULL);
      printf("Parent exited\n");
    }
    return 0;
}

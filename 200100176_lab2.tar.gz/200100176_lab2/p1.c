#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>


void forkexample()
{
    int child;
    if(fork() == 0){
        printf("My process ID is:%d\n", getpid());
        printf("The parent process ID is:%d\n", getppid());
        child = getpid();
        return;
    }
    else{
      wait(NULL);
      printf("My process ID is:%d\n", getpid());
      printf("The child process ID is:%d\n", child);
    }
}
int main()
{
    forkexample();
    return 0;
}

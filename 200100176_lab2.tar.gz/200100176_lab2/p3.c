#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>


int main(){
    while(1){
       printf(">>> ");
       char file_name[50];
       scanf("%s", file_name);
       static char *argv[]={NULL};
       if(fork() == 0){
         execv(file_name, argv);
         print("\n");
         break;
       }
       else{
         wait(NULL);
       }
    }
    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>


int main(int argc, char *argv[]){
    char *a = argv[1];
    int n = atoi(a);
    int i = 1;
    if(fork() == 0){
      for(; i <= n; i++) printf("C %d %d\n", getpid(), i);
    }
    else{
      i = n+1;
      for(; i <= 2*n; i++) printf("P %d %d\n", getpid(), i);
    }
    return 0;
}

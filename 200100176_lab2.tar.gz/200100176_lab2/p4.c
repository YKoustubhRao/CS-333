#include <unistd.h>
#include <fcntl.h> 

int main()
{
	char buf;
	int fd_one, fd_two;

	fd_one = open("file1", O_RDONLY);
	fd_two = open("second_file", 
				  O_WRONLY | O_CREAT,
				  S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
	
	while(read(fd_one, &buf, 1)){
		write(fd_two, &buf, 1);
	}
	
	close(fd_one);
	close(fd_two);
	return 0;
}

#include "ulock.h"
#include "x86.h"
#include "defs.h"

void init_lock(struct lock_t *s) {
    //TODO
    //Set the lock variable to 0
    s->locked = 0;
}

void 
acquire_lock(struct lock_t *s) 
{
    // TODO
    // USE xchg() to atomically set the lock variable to 1
    // sync synchronize the memory access
    // return
    while(xchg(&s->locked, 1) != 0);
    __sync_synchronize();
}

void 
release_lock(struct lock_t *s) 
{   
    // TODO
    // sync synchronize the memory access
    // use asm volatile to set the lock variable to 0
    __sync_synchronize();
    asm volatile("movl $0, %0" : "+m" (s->locked) : );
}


void 
init_sem(struct sem_t *s, int initval)
{
    // TODO
    // set the value of the semaphore to initval
    // initialize the lock
    s->value = initval;
    init_lock(&s->lk);
}

void
up_sem(struct sem_t *s) 
{
    // TODO
    // increment the value of the semaphore
    // wakeup the lock
    acquire_lock(&s->lk);
    s->value = s->value+1;
    wakeup((void*) s);
    release_lock(&s->lk);
}

void 
down_sem(struct sem_t *s) 
{
    // TODO
    // block the semaphore if the value is 0
    // if not, decrement the value of the semaphore
    acquire_lock(&s->lk);
    if(s->value > 0) s->value = s->value-1;
    else{
        while(s->value == 0){
            release_lock(&s->lk);
            block_sem((void*) s);
            acquire_lock(&s->lk);
        }
        s->value = s->value-1;
    }
    release_lock(&s->lk);
}

#include "types.h"

struct lock_t {
    //TODO
    uint locked;
};

// semaphore implementation for xv6
struct sem_t {
    //TODO
    uint value;
    struct lock_t lk;
};


#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h> 


int main(){
    char a,b,c,d,e,f,g,h,i,j;
    int p[2];
    pipe(p);
    if(fork() == 0){
      char a, b, c, d, e;
      int fd_one;
      fd_one = open("secret1.txt", O_RDONLY);
      read(fd_one, &a, 1);
      read(fd_one, &b, 1);
      read(fd_one, &c, 1);
      read(fd_one, &d, 1);
      read(fd_one, &e, 1);
      printf("%d: Secret code for Alice is %c%c%c%c%c\n", getpid(),a,b,c,d, e);
      write(p[1], &a, 1);
      write(p[1], &b, 1);
      write(p[1], &c, 1);
      write(p[1], &d, 1);
      write(p[1], &e, 1);
      close(fd_one);
    }
    else{
      wait(NULL);
      read(p[0], &a, 1);
      read(p[0], &b, 1);
      read(p[0], &c, 1);
      read(p[0], &d, 1);
      read(p[0], &e, 1);
      if(fork() == 0){
        char a, b, c, d, e;
        int fd_two;
        fd_two = open("secret2.txt", O_RDONLY);
        read(fd_two, &a, 1);
        read(fd_two, &b, 1);
        read(fd_two, &c, 1);
        read(fd_two, &d, 1);
        read(fd_two, &e, 1);
        printf("%d: Secret code for Bob is %c%c%c%c%c\n", getpid(),a,b,c,d,e);
        write(p[1], &a, 1);
        write(p[1], &b, 1);
        write(p[1], &c, 1);
        write(p[1], &d, 1);
        write(p[1], &e, 1);
        close(fd_two);
      }
      else{
        wait(NULL);
        read(p[0], &f, 1);
        read(p[0], &g, 1);
        read(p[0], &h, 1);
        read(p[0], &i, 1);
        read(p[0], &j, 1);
        printf("%d: Passcode is %c%c%c%c%c%c%c%c%c%c\n",getpid(),a,b,c,d,e,f,g,h,i,j);
      }
    }
    return 0;
}

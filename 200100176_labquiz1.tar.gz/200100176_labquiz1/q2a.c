#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h> 

int checker = 0;

void sig_handler(int sig){
  checker = 1;
}

int main(int argc, char *argv[]){
    char *file_name = argv[1];
    static char *arg[]={NULL};
    int child_pid = 1+getpid();
    signal(SIGCHLD, sig_handler);
    if(fork() == 0){
       child_pid = getpid();
       printf("pid %d: I am child\n", getpid());
       execv(file_name, arg);
    }
    else{
      sleep(5);
      if(checker == 0){
        printf("Terminating process %d\n", child_pid);
        kill(child_pid, SIGKILL);
      }
    }
    return 0;
}

#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h> 


int main(){
    if(fork() == 0){
      char a, b, c, d, e;
      int fd_one;
      fd_one = open("secret1.txt", O_RDONLY);
      read(fd_one, &a, 1);
      read(fd_one, &b, 1);
      read(fd_one, &c, 1);
      read(fd_one, &d, 1);
      read(fd_one, &e, 1);
      printf("%d: Secret code for Alice is %c%c%c%c%c\n", getpid(),a,b,c,d, e);
      close(fd_one);
    }
    else{
      wait(NULL);
      if(fork() == 0){
        char a, b, c, d, e;
        int fd_two;
        fd_two = open("secret2.txt", O_RDONLY);
        read(fd_two, &a, 1);
        read(fd_two, &b, 1);
        read(fd_two, &c, 1);
        read(fd_two, &d, 1);
        read(fd_two, &e, 1);
        printf("%d: Secret code for Bob is %c%c%c%c%c\n", getpid(),a,b,c,d,e);
        close(fd_two);
      }
      else{
        wait(NULL);
      }
    }
    return 0;
}

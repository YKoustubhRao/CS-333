#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include<signal.h>

int pid;
int check = 0;

void sig_handler(int sig){
  printf("\nshell is exiting\n");
  exit(0);
}

int main(){
    char command[256];
    char newargs[1] = "";
    signal(SIGINT, SIG_IGN);
    signal(SIGQUIT, sig_handler);
    while (1){
        if(check == 1) printf("\n");
        char prompt[] = ">>> ";
        check = 1;
        printf("%s",prompt);
        scanf("%s",command);
        pid = fork();
        if(pid){
            wait(NULL);
        }else{
            signal(SIGINT, SIG_DFL);
            execl(command,newargs,(char*)NULL);
            return 1;
        }
    }
    
    return 0;
}

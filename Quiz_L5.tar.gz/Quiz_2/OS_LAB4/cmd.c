#include "types.h"
#include "stat.h"
#include "user.h"
// #include "wait.h"
// #include <stdio.h>
// #include <sys/wait.h>
// #include <sys/types.h>
// #include <unistd.h>

int main(int argc, char **argv) {
    int pid=fork();
    if (pid==0) {
        exec(argv[1], &argv[1]);
    }
    else wait();
    exit();
}